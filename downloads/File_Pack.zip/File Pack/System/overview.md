# Research to HTML slides

This is the student file pack. Open this folder as your AI workspace and give your AI access to its files. During setup, load `AGENTS.MD` as project instructions if your AI app does not read it automatically. The instructions work with any AI app that can read and write files; researching current topics also needs browsing access.

## Try it

Ask: "Research [your topic] and help me turn the findings into HTML slides using this file pack."

1. The AI gathers findings and source links in `output/research.md`.
2. It suggests possible angles, asks you about your audience and what the slides should accomplish, then proposes an outline in `output/slide-brief.md`. You review and approve the direction.
3. It shows three placeholder-based designs in one `output/design-comparison.html` file. Use the arrow keys or on-screen buttons to compare them. You choose a look; the AI generates `output/slides.html` from the approved outline.
4. Open `output/slides.html` in a browser and ask for revisions. The finished file is an HTML presentation, not a PowerPoint file. Sources and research limitations remain visible for checking” to “Source links and research limitations are recorded in `output/research.md`; relevant sources carry through to the slides

The AI pauses for your decisions before writing the full deck. The finished presentation is a self-contained, offline HTML file with 16:9 desktop slides, simple navigation, and subtle entrance animations. If the AI cannot browse, provide sources and ask it to label anything it cannot verify. It should never invent evidence.

## What's in the pack

| Path | Purpose |
| --- | --- |
| `AGENTS.MD` | Agent instructions that get read with every message. In this project, it explains the workflow, outlines skill writing principles, and requires updating outline.md with any changes. |
| `skills/topic-research.md` | Collects traceable findings about your topic. |
| `skills/slide-direction.md` | Helps you choose an angle and agree on the outline. |
| `skills/html-slides.md` | Makes three visual design options, then builds the chosen HTML slide deck. |
| `skills/iu-branding.md` | Optional example of a branding skill; it shows how custom company branding could guide a slide project. |
| `skills/making-skills.md` | Helps you edit or add reusable skills. |
| `output/` | Created during a run for research, the agreed brief, and the finished HTML. |

To change how the AI works next time, ask it to edit the relevant skill and update this overview. 
