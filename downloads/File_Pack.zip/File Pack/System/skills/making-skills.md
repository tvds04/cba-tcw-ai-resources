---
name: making-skills
description: Use when the user wants to create, edit, improve, name, or organize a skill in this slide workspace.
---

# Making skills

Clarify the repeated task, its trigger, its output, and what a successful run must check. Check existing skills first so the new one does not duplicate an existing responsibility. Write one short, editable Markdown file directly in `skills/`:

```md
---
name: short-kebab-case-name
description: Use when the user [asks for this step or task].
---

# Skill title

[Ordered instructions and a checkable finish condition.]
```

Keep front matter to `name` and `description`. Put actionable steps in the body. Do not create supporting folders, `.claude/`, `.codex/`, `.opencode/`, `agents/openai.yaml`, or an installer unless the user explicitly asks for them. Keep the slide-making skill in the same one-file format as the other local skills.

If a new skill changes the research-to-slides sequence, update `AGENTS.MD` and `overview.md` in the same change. Confirm the trigger finds the right skill and its required file paths exist. Ask the user to try it on a real prompt, then revise the instructions based on what did or did not work.
