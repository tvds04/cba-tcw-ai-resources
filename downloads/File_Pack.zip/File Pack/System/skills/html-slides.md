---
name: html-slides
description: Use when an approved slide outline needs visual design choices and a self-contained HTML presentation.
---

# HTML slides

Create a desktop HTML presentation from an approved `output/slide-brief.md`. Read that brief, `output/research.md`, and any user-provided material before starting. If the outline is not approved, return to `slide-direction.md` and wait. Use the approved outline as the main source of slide content; fill only necessary gaps with wording supported by the research. Preserve source links and attributions where they matter. Do not invent facts.

## 1. Show three designs

Create `output/` if needed, then create one self-contained `output/design-comparison.html` with three distinct design candidates. Give each candidate the same placeholder components so the comparison is about visual design rather than presentation content: a title, subtitle, short body text, and a simple visual or callout area. Use labels such as "Title" and "Subtitle" or neutral filler text. Do not put actual research or slide copy in the comparison.

Make the designs appropriate for the audience and any user-approved branding. Scope each candidate's CSS to its own class so styles cannot affect the other candidates. Include visible Previous and Next buttons and left/right arrow-key navigation to move between candidates. Show the same subtle entrance motion described below. Keep CSS and the small navigation script inside this one HTML file.

Show the comparison to the user and wait for a design choice or requested changes. Do not generate the full deck before they choose.

## 2. Make the deck

Create `output/slides.html` using the chosen design and the approved outline. Make it one file that works offline: inline CSS and JavaScript, no external libraries, remote fonts, or linked asset files. Embed any needed images in the HTML. Target desktop presentation at a 16:9 aspect ratio. Use CSS to scale slides to fit the window without rearranging their content. Keep every slide readable and within the slide area; split crowded content into more slides. Make the slides fullscreen, without any borders around the slidedeck.

Use semantic slide sections and visible Previous and Next buttons. Put these directly on top of the slides, not in a seperate section. A small inline script should make the buttons and left/right arrow keys change slides and keep a slide counter current. For example, the basic structure can be:

```html
<main class="deck">
  <section class="slide">...</section>
  <section class="slide">...</section>
</main>
<nav aria-label="Slide navigation">
  <button type="button">Previous</button>
  <span class="slide-count"></span>
  <button type="button">Next</button>
</nav>
```

Use only subtle entrance motion for text and simple elements, such as a brief fade or slight upward movement when a slide appears. A small stagger is fine. Keep diagrams, backgrounds, and other visuals static; avoid looping or elaborate animations.

Before delivery, check the slide order and text against the approved brief, confirm that sources and images are included where needed, and make sure the HTML contains only the chosen design. Do not atetmpt any visual QA, ask the user to do this instead. Browser review, printing/PDF, PowerPoint conversion, deployment, and editing controls are out of scope unless specifically requested.
