---
name: slide-direction
description: Use when research findings need to become an audience-specific slide direction, presentation brief, and agreed outline before slide generation.
---

# Slide direction

Read `output/research.md` and any user material. Present two or three meaningfully different, evidence-supported ways to frame the topic, with a one-sentence reason for each. Then ask the user in one concise message for what is still unknown: who will see it, what they should take away or do, which angle to pursue, what to include or avoid, approximate length, and whether this is a speaker-led talk or a reading-first deck. Include any material research conflict that requires their judgment. If the user has answered some of these already, do not repeat those questions.

Wait for the user's answer before finalizing the brief. Draft `output/slide-brief.md` with the chosen angle, audience, purpose, main takeaway, constraints, slide count range, density mode, and a slide-by-slide outline. Map each substantive slide to findings or source links in `output/research.md`; mark unsupported but desired claims as research gaps, not facts. Present the outline to the user for approval or edits. Wait for approval before handing off to slide generation. If they change the angle, revise the brief and outline first.

This is the content gate. The visual style gate is handled afterward by `html-slides.md`, which shows three placeholder-based designs in one comparison file and lets the user pick. Do not silently treat a proposed outline as approved or choose a visual style for the user.
