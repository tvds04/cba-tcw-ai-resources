---
name: iu-branding
description: Use only when IU/Indiana University branding is explicitly requested by the user. 
---

# Indiana University Branding

Apply Indiana University's current brand standards to both text and designed
documents. Match the audience and purpose first; branding should make the work
clearer and more recognizably IU, not make it sound promotional when the task is
academic, administrative, or informational.

## Voice and Content

- Write in a clear, confident, community-first voice.
- Be thoughtful, inviting, approachable, trustworthy, and collaborative.
- Put people, place, and concrete outcomes before institutional prestige.
- Show why the work matters and who benefits. Lead with verbs and connect
  purpose to impact.
- Prefer active, specific, human language.
- Avoid bureaucracy, passive constructions, institutional jargon, generic
  headlines, vague claims, buzzwords, and grandiose language.
- Do not make IU the actor in every sentence. Name the students, faculty, staff,
  alumni, partners, or communities doing and experiencing the work.
- Keep content inclusive and invitational. Do not invent achievements, impact,
  rankings, quotations, partnerships, or statistics.

## Editorial Style

- Use `Indiana University` or `IU`; never write `I.U.`
- Lowercase `university` when it is not part of a full formal name.
- Use official names for campuses, schools, departments, offices, programs, and
  policies. Capitalize formal names; lowercase shortened or generic references.
- Use sentence case for headings and headlines.
- Use the Oxford comma, except in news stories that explicitly follow AP style.
- Use em dashes without spaces. Use curly quotation marks and apostrophes in
  publications, but straight quotation marks in code and structured data.
- IU preferences include `healthcare`, `well-being`, and `toward`.
- Avoid unfamiliar abbreviations. Spell out a name on first reference when the
  audience may not recognize its abbreviation.

Use these approved campus forms when relevant:

- Indiana University Bloomington; IU Bloomington
- Indiana University Indianapolis; IU Indianapolis
- Indiana University East; IU East
- Indiana University Kokomo; IU Kokomo
- Indiana University Northwest; IU Northwest
- Indiana University South Bend; IU South Bend
- Indiana University Southeast; IU Southeast
- Indiana University Columbus; IU Columbus
- Indiana University Fort Wayne; IU Fort Wayne

In running text, use `Indiana University Indianapolis` on first reference. In
informal contexts, `IU Indy` may be used after that first reference. Never use
`IUI` or another invented abbreviation.

## Visual Identity for Word Documents

- When available, start from IU's current Flexible Microsoft Word template. It
  is intended for everyday course materials, memos, letters, meeting notes,
  program descriptions, summaries, updates, and informational documents.
- Use a restrained, crimson-led palette. IU Crimson is `#990000` (PMS 201 C;
  CMYK 0/100/65/34). Use white as the normal page background and `#191919` or
  black for body text. IU Cream is `#EDEBEB`, but IU notes that white generally
  substitutes for cream in practical applications.
- Keep crimson and white dominant. If a secondary color is needed, use it
  sparingly and do not let it overpower the primary colors.
- Use Benton Sans as the primary typeface, Georgia Pro as the supportive serif,
  and Azeret Mono only for small tertiary text such as captions or notations.
  If licensed brand fonts are unavailable, use an accessible fallback such as
  Arial or Aptos for sans serif and Georgia for serif. Do not download or embed
  fonts without permission.
- Use real Word heading styles, lists, tables, headers, and footers. Maintain a
  clear type hierarchy, comfortable spacing, and readable table geometry.
- For ordinary documents, use US Letter size unless the user or an existing
  template requires otherwise.

## Logos, Signatures, and Marks

- Never redraw, approximate, stretch, recolor, embellish, or otherwise alter the
  IU trident, tab, lockup, signature, seal, or other university artwork.
- Use only approved master artwork supplied by IU or the user. If no approved
  asset is available, create a well-branded text-and-color document without
  inventing a logo.
- Use official signatures for stationery, official documents, and ceremonial
  materials. Use marketing lockups for marketing and communications materials.
- Spell out `Indiana University` in a lockup; `IU` is not permitted there.
  Spell out school names and avoid symbols or unfamiliar acronyms unless they
  are part of the unit's established official name.
- Do not use the IU seal for everyday materials. It is reserved for authorized
  ceremonial, executive, legal, and other officially sanctioned uses.

## Accessibility

- Maintain sufficient foreground/background contrast and never use color alone
  to communicate meaning.
- Use descriptive headings, meaningful link text, real list structures, table
  header rows, logical reading order, and alt text for informative images.
- Keep body text comfortably readable and avoid dense pages, cramped tables,
  or large blocks of crimson text.
- For a QR code, also provide a readable short URL.

## Final Check

Before delivery, verify that the result:

1. Fits the audience, purpose, and channel.
2. Sounds clear, human, inclusive, specific, and impact-oriented.
3. Uses official names and IU editorial conventions.
4. Uses a restrained crimson, white, and black visual system.
5. Uses only approved, unaltered IU marks, if any.
6. Is accessible and visually legible.
7. For a Word document, has been rendered and visually reviewed when rendering
   tools are available.

## Official Sources

These are the source of truth. If a detail is uncertain or likely to have
changed, verify it here before finalizing high-visibility materials:

- [IU brand](https://brand.iu.edu/)
- [Voice and tone](https://brand.iu.edu/iu-brand/content-strategy/voice-tone.html)
- [Editorial style](https://brand.iu.edu/iu-brand/content-strategy/editorial-style/index.html)
- [Official campus names and abbreviations](https://brand.iu.edu/iu-brand/content-strategy/editorial-style/i.html)
- [Visual identity and typography](https://brand.iu.edu/iu-brand/visual-identity/index.html)
- [IU color palette](https://brand.iu.edu/iu-brand/visual-identity/color.html)
- [Logo and marks](https://brand.iu.edu/iu-brand/visual-identity/logo-marks/index.html)
- [Marketing lockups](https://brand.iu.edu/iu-brand/visual-identity/logo-marks/marketing-lockups.html)
- [Official Word and digital templates](https://brand.iu.edu/tools/digital.html)
- [IU accessibility](https://accessibility.iu.edu/)
