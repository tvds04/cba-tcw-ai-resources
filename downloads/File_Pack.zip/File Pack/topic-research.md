---
name: topic-research
description: Use when the user asks to research a topic, gather findings, or start a research-to-slides presentation.
---

# Topic research

Produce a research base before proposing a slide story. Read user-supplied notes and references first; confirm the topic and any limits that genuinely block research. Search for credible primary sources when available (official publications, original studies, datasets, direct statements), using independent sources for contested claims. Record publication dates and distinguish when something happened from when a page was updated. Do not turn a search snippet into evidence without checking the underlying page.

Save findings in `output/research.md` with:

- Topic and research date; whether live browsing was available.
- A short set of possible presentation angles grounded in what the sources actually support.
- For each useful finding: a plain-language claim, source title and direct URL (or supplied-file name and page), date if known, and how it might help the audience. Separate facts from interpretation.
- Conflicting evidence, open questions, missing information, and claims that still need verification.
- A source list that a reader can follow without access to the agent's tool output.

Use only facts you can trace. Do not invent statistics or present opinion as consensus. For changing topics, prioritize recent sources and label older sources. If browsing is unavailable or a source cannot be opened, mark the limits explicitly and ask for material when needed. Do not claim that research was done on the live web when it was not.

Finish when each suggested angle is backed by at least one traceable finding, and the limits of the evidence are visible. Hand the findings to `slide-direction.md`; do not start drafting the deck.
